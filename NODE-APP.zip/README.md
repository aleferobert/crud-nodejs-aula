# CRUD NODE APP - MONGODB

As variaveis do Nodemailer podem ser ignoradas e o número de confirmação aparecerá no console.log.


## Enviroment Variables
* PORT   - Porta do servidor
* MONGOURL - URL Completa do mongodb
* HOSTMAIL - SMTP URL
* PORTMAIL - SMTP Porta
* USERMAIL - Email
* SERVERMAIL - Email público
* PASSMAIL - Senha do Email
* NEO4JURL - URL Completo do Neo4j
* NEO4JUSER - Usuario do Neo4j
* NEO4JPASS - Senha do Usuário
* NEO4JDATABASE - Nome do banco de dados
